import org.jsoup.*;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.regex.*;

public class Nets {

	// How many awards was Alfonso Cuarón nominated for? List them.
	private static void one(String actor, String url) throws IOException {
		int numberOfNominations = 0;
		Document doc = Jsoup.connect(url).get();
		Element table = doc.getElementsByClass("wikitable").first();

		for (Element row : table.getElementsByTag("tr")) {
			for (Element col : row.getElementsByTag("td")) {
				String str = col.text();
				if (str.contains(actor)) {
					if (!str.contains("as " + actor)) {
						numberOfNominations++;
					}
				}
			}
		}

		System.out.println(actor + " was nominated " + numberOfNominations + " times.");
	}

	// List all the movies that were nominated for at least 3 awards.
	private static void two(String url) throws IOException {
		int num = 0;
		ArrayList<String> allMovies = new ArrayList<String>();
		Document doc = Jsoup.connect(url).get();
		Element table = doc.getElementsByClass("wikitable").get(2);
		Elements setTd = table.select("td");

		// get movies
		for (Element e : setTd) {
			String template = "(-?\\d+)";
			Pattern p = Pattern.compile(template);
			Matcher m = p.matcher(e.text());
			if (m.find()) {
				num = Integer.parseInt(m.group(1));
			} else if (num >= 3) {
				allMovies.add(e.text());
			}
		}

		for (String e : allMovies) {
			if (allMovies.get(0) == e) {
				System.out.print("2. " + e + ", ");
			} else if (allMovies.get(allMovies.size() - 1) == e) {
				System.out.print(e + ".");
				System.out.println();
			} else {
				System.out.print(e + ", ");
			}
		}
	}

	// When was the award for Best Actress first awarded? Who won the award that
	// year?
	private static void three(String award, String url) throws IOException {
		// get the link
		url = "https://en.wikipedia.org/wiki/Academy_Award_for_" + award.replace(" ", "_");

		// get the table
		Document doc = Jsoup.connect(url).get();
		Element table = doc.select("table[border=\"2\"]").get(0);

		// get the winner
		Element row = table.select("tr").get(1).select("td").get(0);

		int year = 0;

		String template = "(\\d+?)/";
		Pattern p = Pattern.compile(template);
		Matcher m = p.matcher(table.text());
		if (m.find()) {
			String s = m.group(0);
			s = s.substring(0, s.indexOf("/"));
			year = Integer.parseInt(s);
		}

		award = award.replace("_", " ");
		System.out.println(row.text() + " was first awarded " + award + " in " + year + ".");

	}

	// What was the budget for the Best Original Screenplay winner? How much did
	// this movie make in the box office?
	private static void four(String url, String nomination) throws IOException {
		ArrayList<String> allMovies = new ArrayList<String>();
		Document doc = Jsoup.connect(url).get();
		Element table = doc.getElementsByClass("wikitable").get(0);
		Elements bold = table.select("b");

		String s = null;
		for (int i = 0; i < bold.size(); i++) {
			String str = bold.get(i).text();
			if (str.equals(nomination)) {
				Element below = bold.get(i + 1);
				s = below.select("a").attr("href");
			}
		}

		// link to best original screen play winner - Green Book
		Document d = Jsoup.connect("https://en.wikipedia.org/" + s).get();

		// find budget
		Element t = d.getElementsByClass("infobox vevent").get(0);
		Elements setTr = t.select("tr");

		String budget = setTr.get(setTr.size() - 2).text();
		String subBudget = budget.substring(0, budget.indexOf("["));

		// find money
		String money = setTr.get(setTr.size() - 1).text();
		String subMoney = money.substring(0, budget.indexOf("["));

		System.out.println("4. " + subBudget + ", money made in " + subMoney);

	}

	// Which of the nominees for Best Documentary – Feature has the shortest running
	// time?
	private static void five(String url, String nomination) throws IOException {
		Document doc = Jsoup.connect(url).get();
		Element table = doc.getElementsByClass("wikitable").get(0);
		Elements tables = table.select("td");
		Element cell = null;

		// find table with that nomination
		for (Element e : tables) {
			if (e.text().contains(nomination)) {
				cell = e;
			}
		}

		HashMap<String, Integer> hmap = new HashMap<>();

		for (Element movie : cell.select("li")) {
			String s = (movie.select("a").attr("href"));
			url = "https://en.wikipedia.org/" + s;
			hmap.put(movie.select("a").attr("title"), getTime(url));
		}

		// find minimum time and movie associated with it in HashMap
		int min = 0;
		String movieName = null;
		for (String move : hmap.keySet()) {
			if ((hmap.get(move) < min) || (min == 0)) {
				min = hmap.get(move);
				movieName = move;
			}
		}

		System.out.println("5. " + movieName + " has the shortest runtime of " + min + " in " + nomination + ".");
	}

	// helper function to get the running time
	private static int getTime(String url) throws IOException {
		Document doc = Jsoup.connect(url).get();
		Element table = doc.getElementsByClass("infobox vevent").get(0);
		Elements tab = table.select("tr");

		for (Element item : tab) {
			if (item.text().contains(" min")) {
				String template = "Running time (\\d+) min";
				Pattern p = Pattern.compile(template);
				Matcher m = p.matcher(item.text());
				if (m.find()) {
					return Integer.parseInt(m.group(1));
				}
			}
		}
		return 0;
	}

	// Which company distributed the most films that received multiple nominations?
	private static void six(String url, String question) throws IOException {
		Document doc = Jsoup.connect(url).get();
		Element table = doc.getElementsByClass("wikitable").get(2);

		HashMap<String, Integer> hmap = new HashMap<>();

		for (Element m : table.getElementsByTag("tr")) {
			for (Element movie : m.getElementsByTag("td")) {
				String template = "(-?\\d+)";
				Pattern p = Pattern.compile(template);
				Matcher mm = p.matcher(movie.text());
				if (!mm.find()) {
					url = "https://en.wikipedia.org/" + (movie.select("a").attr("href"));
					String producers = getProducers(url, question);
					if (hmap.containsKey(producers)) {
						hmap.put(producers, hmap.get(producers) + 1);
					} else {
						hmap.put(producers, 1);
					}
				}
			}
		}

		// find max number of films in HashMap
		int max = 0;
		String company = null;
		for (String move : hmap.keySet()) {
			if (hmap.get(move) >= max) {
				max = hmap.get(move);
				company = move;
			}
		}

		System.out.println(
				"6. " + company + " distributed the most films (" + max + ") that received multiple nominations.");

	}

	// helper function to get producers
	private static String getProducers(String url, String question) throws IOException {
		Document doc = Jsoup.connect(url).get();
		Element table = doc.getElementsByClass("infobox vevent").get(0);
		Elements tab = table.select("tr");

		for (Element item : tab) {
			if (item.text().contains(question)) {
				String s = item.text().substring((question.length() + 1), item.text().length());
				return s;
			}
		}

		return "";
	}

	// For Best Foreign Language Film, for the countries that were nominated/won,
	// how many times have they
	// been nominated in the past (including this year)?
	// For Best Foreign Language Film, for the countries that were nominated/won,
	// how many times have they been nominated in the past (including this year)?
	private static void seven(String url, String nomination) throws IOException {
		Document doc = Jsoup.connect(url).get();
		Element table = doc.getElementsByClass("wikitable").get(0);
		// store countries from that table
		ArrayList<String> countries = new ArrayList<>();
		if (nomination.equals("Best Foreign Language Film")) {
			HashMap<String, Integer> hmap = goToBestForeignFilm(
					"https://en.wikipedia.org/wiki/List_of_countries_by_number_of_Academy_Awards_for_Best_Foreign_Language_Film");

			for (Element col : table.select("td")) {
				if (col.text().contains(nomination)) {
					for (Element m : col.select("li")) {
						Element k = m.select("a").get(1);
						if (!countries.contains(k.text())) {
							countries.add(k.text());
						}
					}
				}
			}

			for (String s : countries) {
				for (String country : hmap.keySet()) {
					if (country.equals(s)) {
						System.out.println("In category " + nomination + ", " + country + " was nominated/won "
								+ hmap.get(country) + " times.");
					}
				}
			}

		} else {

			HashMap<String, Integer> movies = null;
			for (Element col : table.select("td")) {
				if (col.text().contains(nomination)) {
					for (Element m : col.select("li")) {
						Element k = m.select("a").get(0);
						if (!countries.contains(k.text())) {
							countries.add(k.text());
							String s = "https://en.wikipedia.org/" + (k.select("a").attr("href"));
							String country = getCountry(s);
							System.out.println(country);
						}
					}
				}
			}
		}
	}

	// helper function to get the country
	private static String getCountry(String url) throws IOException {
		Document doc = Jsoup.connect(url).get();
		Element table = doc.getElementsByClass("infobox vevent").get(0);
		Elements tab = table.select("tr");

		for (Element item : tab) {
			String template = "Country (\\w*)";
			Pattern p = Pattern.compile(template);
			Matcher m = p.matcher(item.text());
			if (m.find()) {
				return m.group(1);
			}
		}
		return "";
	}

	private static HashMap<String, Integer> goToBestForeignFilm(String url) throws IOException {
		Document doc = Jsoup.connect(url).get();
		Element table = doc.getElementsByTag("table").get(0);
		HashMap<String, Integer> hmap = new HashMap<>();

		for (Element row : table.select("tr")) {
			String a = row.text().replace("&", "");
			String b = a.replace("+", "");

			String template = "(.*) (\\d+) (\\d+) (\\d+)";
			Pattern p = Pattern.compile(template);
			Matcher m = p.matcher(b);
			if (m.find()) {
				String country = m.group(1);
				if (country.indexOf("[") != -1) {
					country = country.substring(0, country.indexOf("["));
				}
				int nom = Integer.parseInt(m.group(3));
				hmap.put(country, nom);
			}

		}
		return hmap;

	}

	private static HashMap<String, Integer> goThroughTable(String url) throws IOException {
		Document doc = Jsoup.connect(url).get();
		Elements tables = doc.getElementsByClass("wikitable");
		HashMap<String, Integer> hmap = new HashMap<>();

		for (Element table : tables) {
			for (Element row : table.select("tr")) {
				String link = row.select("td").select("a").attr("href");
				if ((link.indexOf("/wiki") != -1) && !link.contains("_in_film")) {

					link = "https://en.wikipedia.org/" + link;
					// System.out.println(link);

					Document d = Jsoup.connect(link).get();
					Element t = d.getElementsByClass("infobox vevent").first();
					if (t != null) {
						Elements tab = t.getElementsByTag("tr");
						String country = "";

						for (Element item : tab) {
							if (item.text().contains("Country")) {
								country = item.text().substring(8, item.text().length());

								if (country.indexOf("[") != -1) {
									country = country.substring(0, country.indexOf("["));
								}

								if (!hmap.keySet().contains(country)) {
									hmap.put(country, 1);
								} else {
									hmap.put(country, hmap.get(country) + 1);
								}
							}
						}
					}
				}
			}
		}

		return hmap;

	}

	// Which movie has the most Box Office Gross for Best Picture Nominees and what
	// is it?
	private static void eight(String url) throws IOException {
		Document doc = Jsoup.connect(url).get();
		Element table = doc.select("table").get(6);
		HashMap<String, Double> hmap = new HashMap<>();
		for (Element row : table.select("tr")) {
			Element mov = row.select("td").first();
			if (mov != null) {

				String movie = mov.text();
				if (movie.contains("[")) {
					movie = movie.substring(0, mov.text().indexOf("["));
				}

				Element money = row.select("td").get(1);

				String template = "(\\d+).(\\d) million";
				Pattern p = Pattern.compile(template);
				Matcher m = p.matcher(money.text());
				if (m.find()) {
					double num = Double.parseDouble(m.group(1) + "." + m.group(2));
					hmap.put(movie, num);
				}

			}
		}

		Double max = 0.0;
		String movieName = null;
		for (String move : hmap.keySet()) {
			if (hmap.get(move) >= max) {
				max = hmap.get(move);
				movieName = move;
			}
		}
		System.out.println(movieName + " has the most Box Office Gross for Best Picture Nominees of $" + max
				+ " million in total.");

	}

	public static void main(String[] args) {
		try {
			String url = "https://en.wikipedia.org/wiki/91st_Academy_Awards";
			System.out.println("Which question you want to be answered?");
			if (args[0].equals("one")) {
				one("Alfonso Cuarón", url);
			} else if (args[0].equals("two")) {
				two(url);
			} else if (args[0].equals("three")) {
				three("Best Actress", url);
			} else if (args[0].equals("four")) {
				four(url, "Best Original Screenplay");
			} else if (args[0].equals("five")) {
				five(url, "Best Documentary – Feature");
			} else if (args[0].equals("six")) {
				six(url, "Distributed by");
			} else if (args[0].equals("seven")) {
				seven(url, "Best Foreign Language Film");
			} else if (args[0].equals("eight")) {
				eight(url);
			}
		} catch (IOException e) {
			System.out.println("Could not get the page!");
			e.printStackTrace();
		}

	}

}
